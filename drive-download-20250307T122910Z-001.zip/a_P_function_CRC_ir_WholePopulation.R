# r_HD[t]<--log(1-p_HDage[t])
# p_D_1[t] <-1-exp(-r_HD[t]*rr_1) relative risk
# https://github.com/FredHutch/IC-RISC-Working/tree/master/input_data

RateToProb <- function(r, t) {
 # Function to convert rates to probabilities
 # Arg:
 # r: the annual input rate
 # t: the cycle length of your model in years
 #
 # Retrun:
 # probability for the time interval
 1 - exp(-r * t)
}

probtoodds<-function(x){
# Function to convert probabilities to odds
 # Arg:
 # x: probability
 x/(1-x)
}

oddstoprob<-function(x){
 # Function to convert odds to probability
 # Arg:
 # x: odds
 x/(x+1)
}

a_P_function_CRC_Wieszczy_sc<-function(n_age_init,n_age_max,p_hdage,psa){

p_HDage<-p_hdage
Strategy<-psa$Strategy


################# patients with nonadvanced adenoma at baseline have a 10-year cumulative CRC incidence and mortality of 0.44 % (95 %CI 0.31 % – 0.62 %) and 0.03 % (95 %CI 0.01 % – 0.11 %), respectively, similarly to patients without adenoma at baseline

###### whole NS incidence rate 
IR_1<-psa$IR_1

### relative risk UC - control colonoscopy
HR_1<-psa$HR_1

HR_A1<-psa$HR_A1
HR_A2<-psa$HR_A2
HR_A3<-psa$HR_A3

# Initialize 3-D array
a_P <- array(0, dim = c(n_states, n_states, n_t),dimnames = list(v_n, v_n, 0:(n_t - 1)))

### Fill in array
##### Parameter #############
# normal to other states
# Rates were converted to 1-year probabilities
# In the natural history module, we modeled that 8.2% of patients develop non-polypoid CRC in their lifetime by using an age-specific annual transition probability for developing non- polypoid CRC of 0.001-0.086%.
### H to other states # 29.05/100000*94097/(94097+48491)+13.68/100000*48491/(94097+48491)

age<-n_age_init+1
n_tt<-length(p_HDage)

#	annual transiction probability - 0.44/100 10-year cumulative incidence
	
	r_14<-9.35/20000
	
	r_14A<-3.82/20000
	r_14B<-2.18/20000
	r_14C<-1.93/20000
	r_14D<-1.42/20000
		
	a_P["H","D",1:n_tt]<-p_HDage[1:n_tt]
	a_P["H","DA",1:n_tt]<-(1-p_HDage[1:n_tt])*r_14A
	a_P["H","CL",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*r_14B
	a_P["H","CR",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*r_14C
	a_P["H","DC",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*(1-r_14C)*r_14D
	
	a_P["H","H",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*(1-r_14C)*(1-r_14D)
	
##### High risk surveillance - annual probability of CRC
	r_34<-0.0011
	r_32<-0.00
	
#### first surveillance 3 years
        
#	r_34A<-2.6/10000       # 2.6 5.87/10000 # 0.36*r_34
#	r_34B<-4.1/10000        # 4.1 9.23/10000 # 0.34*r_34
#	r_34C<-2.8/10000        # 2.8 6.29/10000 # 0.25*r_34
#	r_34D<-1.5/10000        # 1.5 3.45/10000 # 0.05*r_34
#	r_32<-530/10000
	
#	a_P["HG","D",]<-p_HDage
#	a_P["HG","SympA",]<-r_34A*(1-p_HDage)
#	a_P["HG","SympL",]<-(1-r_34A)*(1-p_HDage)*r_34B
#	a_P["HG","SympR",]<-(1-r_34A)*(1-p_HDage)*(1-r_34B)*r_34C
#	a_P["HG","SympD",]<-(1-r_34A)*(1-p_HDage)*(1-r_34B)*(1-r_34C)*r_34D
#	a_P["HG","H",]<-(1-r_34A)*(1-p_HDage)*(1-r_34B)*(1-r_34C)*(1-r_34D)*r_32
#	a_P["HG","HG",]<-(1-r_34A)*(1-p_HDage)*(1-r_34B)*(1-r_34C)*(1-r_34D)*(1-r_32)

	r_34A<-1-exp(-2.6/10000*3)       # 2.6 5.87/10000 # 0.36*r_34
	r_34B<-1-exp(-4.1/10000*3)        # 4.1 9.23/10000 # 0.34*r_34
	r_34C<-1-exp(-2.8/10000*3)        # 2.8 6.29/10000 # 0.25*r_34
	r_34D<-1-exp(-1.5/10000*3)        # 1.5 3.45/10000 # 0.05*r_34

	a_P["HG","D",1:2]<-p_HDage[1:2]
	a_P["HG","HG",1:2]<-(1-p_HDage[1:2])
	
	a_P["HG","D",3]<-p_HDage[3]
	a_P["HG","SympA",3]<-(1-p_HDage[3])*r_34A
	a_P["HG","SympL",3]<-(1-p_HDage[3])*(1-r_34A)*r_34B
	a_P["HG","SympR",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*r_34C
	a_P["HG","SympD",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*(1-r_34C)*r_34D
	a_P["HG","HG",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*(1-r_34C)*(1-r_34D)
	
	a_P["HG","D",4:5]<-p_HDage[4:5]
	a_P["HG","HG",4:5]<-(1-p_HDage[4:5])
	
	r_34A<-1-exp(-2.6/10000*3*0.81)       # 2.6 5.87/10000 # 0.36*r_34
	r_34B<-1-exp(-4.1/10000*3*0.81)        # 4.1 9.23/10000 # 0.34*r_34
	r_34C<-1-exp(-2.8/10000*3*0.81)        # 2.8 6.29/10000 # 0.25*r_34
	r_34D<-1-exp(-1.5/10000*3*0.81)        # 1.5 3.45/10000 # 0.05*r_34
	
	a_P["HG","D",6]<-p_HDage[6]
	a_P["HG","H",6]<-(1-p_HDage[6])*r_32
	a_P["HG","SympA",6]<-(1-p_HDage[6])*(1-r_32)*r_34A
	a_P["HG","SympL",6]<-(1-p_HDage[6])*(1-r_32)*(1-r_34A)*r_34B
	a_P["HG","SympR",6]<-(1-p_HDage[6])*(1-r_32)*(1-r_34A)*(1-r_34B)*r_34C
	a_P["HG","SympD",6]<-(1-p_HDage[6])*(1-r_32)*(1-r_34A)*(1-r_34B)*(1-r_34C)*r_34D
	a_P["HG","HG",6]<-(1-p_HDage[6])*(1-r_32)*(1-r_34A)*(1-r_34B)*(1-r_34C)*(1-r_34D)

	a_P["HG","D",7:n_tt]<-p_HDage[7:n_tt]
	a_P["HG","HG",7:n_tt]<-(1-p_HDage[7:n_tt])
		
# DA (4) to other states CL (5) D (11) DA (4) SympL (8)

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_45<-0.51 # 0.51 # (0.50, 0.89)  
	r_48<-0.09 # 0.09 (0.0694, 0.1006)    
	    
      	a_P["DA","D",i]<-p_HDage[i]
	a_P["DA","SympA",i]<-(1-p_HDage[i])*r_48
	a_P["DA","CL",i]<-(1-p_HDage[i])*(1-r_48)*r_45
	a_P["DA","DA",i]<-(1-r_48)*(1-p_HDage[i])*(1-r_45)      	  	
}
se_crc<-0.98

a_P["DA","SympA",1]<-se_crc
a_P["DA","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["DA","DA",1]<-(1-se_crc)*(1-p_HDage[1])

# CL (5) to other states CR (6), D (11) CL (5), SympL (8)

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_56<-0.43 # 0.50 # 0.69 (0.50, 0.70)	
	r_58<-0.17 # (0.12, 0.18)
		
      	a_P["CL","D",i]<-p_HDage[i]
	a_P["CL","SympL",i]<-(1-p_HDage[i])*r_58
	a_P["CL","CR",i]<-(1-r_58)*(1-p_HDage[i])*r_56	
	a_P["CL","CL",i]<-(1-p_HDage[i])*(1-r_56)*(1-r_58)
}

se_crc<-0.98

a_P["CL","SympL",1]<-se_crc
a_P["CL","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["CL","CL",1]<-(1-se_crc)*(1-p_HDage[1])

# CR (6) to other states DC (7) SympD (9) D (11) CR (6)

for(i in 2:length(p_HDage)){

    
	age<-n_age_init+i
	
	r_67<-0.59 # 0.59 # 0.71 (0.59, 0.73)
	r_69<-0.37 # 0.37 (0.30, 0.39)	

# probability presenting sympts with Reg. 0.49 (0.4115, 0.5269) preseting sympts with Reg
	
      	a_P["CR","D",i]<-p_HDage[i]
	a_P["CR","SympR",i]<-(1-p_HDage[i])*r_69
	a_P["CR","DC",i]<-(1-p_HDage[i])*(1-r_69)*r_67
	a_P["CR","CR",i]<-(1-p_HDage[i])*(1-r_69)*(1-r_67)	
		
}

se_crc<-0.98

a_P["CR","SympR",1]<-se_crc
a_P["CR","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["CR","CR",1]<-(1-se_crc)*(1-p_HDage[1])

# DC (7) to other states SympD (10); D (11); 

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_710<-0.65 # 0.82 (0.6109, 0.9891) 0.65 (0.65, 0.92)
		
      	a_P["DC","D",i]<-p_HDage[i]
	a_P["DC","SympD",i]<-r_710*(1-p_HDage[i])
	a_P["DC","DC",i]<-(1-r_710)*(1-p_HDage[i])
}

se_crc<-0.98

a_P["DC","SympR",1]<-se_crc
a_P["DC","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["DC","DC",1]<-(1-se_crc)*(1-p_HDage[1])

# Clinical Cancer to other study - It was assumed that all those surviving for five years would no longer be at risk from CRC mortality. In the model, those diagnosed with CRC are split into fatal and non-fatal CRC health states according to the proportions given by the five year survival data.
# OS Dukes A 0.01568434/year 
# Supplement to: Overall and stage-specific survival of patients with screen-detected colorectal cancer in European countries: a population-based study in 9 countries
## 95.7 (94.3-96.8) screening arm vs. 93.1 (90.9-94.7) no-screening
## 94.6 (92.1-96.3)  screening vs. 85.1 (82.8-87.1)

# r_1<-0.028 # 0.02900678 # 91.0 (89.2-92.4) 5-year OS 86.7 (86.0-87.4) in no-screening and 92.4 (91.6-93.1) in screening 

r_1<-psa$death_S1 

hr_S1<-psa$hr_S1

if(Strategy!="NS")
   r_1<-hr_S1*r_1

# p_S1<-r_1
# r_1<-p_S1

p_S1<-RateToProb(r_1,1)

a_P["SympA","DL",]<-r_1
a_P["SympA","D",]<-(1-r_1)*p_HDage
a_P["SympA","SA",]<-(1-r_1)*(1-p_HDage)

r_1<-psa$death_S2  # 0.047 # 0.04663878 # OS 5-years 79.2 (77.6-82.5) in no-screening vs. 87.9 (86.6-89.1) in screening

hr_S2<-psa$hr_S2

if(Strategy!="NS")
r_1<-hr_S2*r_1

p_S2<-RateToProb(r_1,1)
# p_S2<-r_1
r_1<-p_S2

a_P["SympL","DL",]<-r_1
a_P["SympL","D",]<-(1-r_1)*(p_HDage)
a_P["SympL","SL",]<-(1-r_1)*(1-p_HDage)

# https://www.sciencedirect.com/science/article/pii/S1542356523001775#appsec1
# r_1<-0.08249794 # 5-year OS 66.2 (65.3-66.9) in no-screening vs, 80.7 (79.3-82.0)

r_1<-psa$death_S3

hr_S3<-psa$hr_S3

if(Strategy!="NS")
 r_1<-hr_S3*r_1

p_S3<-RateToProb(r_1,1)

p_S3<-r_1
r_1<-p_S3

a_P["SympR","DR",]<-r_1
a_P["SympR","D",]<-(1-r_1)*(p_HDage)
a_P["SympR","SR",]<-(1-r_1)*(1-p_HDage)

# r_1<-0.4080442 # 13.4 (11.2-15.8) 32.3 (29.4-35.2) in screening vs. 13.9 (13.3-14.5) in no-screening

r_1<-psa$death_S4

hr_S4<-psa$hr_S4

if(Strategy!="NS")
	r_1<-hr_S4*r_1
	
p_S4<-RateToProb(r_1,1)
# p_S4<-r_1
r_1<-p_S4

a_P["SympD","DD",]<-r_1
a_P["SympD","D",]<-(1-r_1)*(p_HDage)
a_P["SympD","SympD1",]<-(1-p_HDage)*(1-r_1)

a_P["SympD1","DD",]<-r_1
a_P["SympD1","D",]<-(1-r_1)*(p_HDage)
a_P["SympD1","SympD1",]<-(1-p_HDage)*(1-r_1)

# Treatened Clinical cancer
###########
# 5 year relative survival percent 89.8 localized

r_1<-p_S1

a_P["SA","DL",]<-r_1
a_P["SA","D",]<-(1-r_1)*p_HDage
a_P["SA","SA1",]<-(1-r_1)*(1-p_HDage)

a_P["SA1","DL",]<-r_1
a_P["SA1","D",]<-(1-r_1)*(p_HDage)
a_P["SA1","SA2",]<-(1-r_1)*(1-p_HDage)

a_P["SA2","DL",]<-r_1
a_P["SA2","D",]<-(1-r_1)*(p_HDage)
a_P["SA2","SA3",]<-(1-r_1)*(1-p_HDage)

a_P["SA3","D",]<-r_1
a_P["SA3","DL",]<-(1-r_1)*(p_HDage)
a_P["SA3","SurvivalA",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S2

a_P["SL","DL",]<-r_1
a_P["SL","D",]<-(1-r_1)*(p_HDage)
a_P["SL","SL1",]<-(1-r_1)*(1-p_HDage)

a_P["SL1","DL",]<-r_1
a_P["SL1","D",]<-(1-r_1)*(p_HDage)
a_P["SL1","SL2",]<-(1-r_1)*(1-p_HDage)

a_P["SL2","DL",]<-r_1
a_P["SL2","D",]<-(1-r_1)*(p_HDage)
a_P["SL2","SL3",]<-(1-r_1)*(1-p_HDage)

a_P["SL3","DL",]<-r_1
a_P["SL3","D",]<-(1-r_1)*(p_HDage)
a_P["SL3","SurvivalL",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S3

a_P["SR","DR",]<-r_1
a_P["SR","D",]<-(1-r_1)*(p_HDage)
a_P["SR","SR1",]<-(1-r_1)*(1-p_HDage)

a_P["SR1","DR",]<-r_1
a_P["SR1","D",]<-(1-r_1)*(p_HDage)
a_P["SR1","SR2",]<-(1-r_1)*(1-p_HDage)

a_P["SR2","DR",]<-r_1
a_P["SR2","D",]<-(1-r_1)*(p_HDage)
a_P["SR2","SR3",]<-(1-r_1)*(1-p_HDage)

a_P["SR3","DR",]<-r_1
a_P["SR3","D",]<-(1-r_1)*(p_HDage)
a_P["SR3","SurvivalR",]<-(1-r_1)*(1-p_HDage)

a_P["SurvivalL","D",]<-p_HDage
a_P["SurvivalL","SurvivalL",]<-(1-p_HDage)

a_P["SurvivalR","D",]<-p_HDage
a_P["SurvivalR","SurvivalR",]<-(1-p_HDage)

a_P["SurvivalA","D",]<-p_HDage
a_P["SurvivalA","SurvivalA",]<-(1-p_HDage)

a_P["D","D",]<-1
a_P["DD","DD",]<-1
a_P["DL","DL",]<-1
a_P["DR","DR",]<-1

a_P["PHG","D",]<-p_HDage
a_P["PHG","PHG",]<-(1-p_HDage)

a_P["PH","D",]<-p_HDage
a_P["PH","PH",]<-(1-p_HDage)

a_P["PLR","D",]<-p_HDage
a_P["PLR","PLR",]<-(1-p_HDage)

return(a_P)
}


a_P_function_CRC_Wieszczy_ai<-function(n_age_init,n_age_max,p_hdage,psa){

p_HDage<-p_hdage
Strategy<-psa$Strategy


################# patients with nonadvanced adenoma at baseline have a 10-year cumulative CRC incidence and mortality of 0.44 % (95 %CI 0.31 % – 0.62 %) and 0.03 % (95 %CI 0.01 % – 0.11 %), respectively, similarly to patients without adenoma at baseline

###### whole NS incidence rate 
IR_1<-psa$IR_1

### relative risk UC - control colonoscopy

HR_1<-psa$HR_1

HR_A1<-psa$HR_1 # psa$HR_A1
HR_A2<-psa$HR_2 # psa$HR_A2
HR_A3<-psa$HR_3 # psa$HR_A3

# Initialize 3-D array
a_P <- array(0, dim = c(n_states, n_states, n_t),dimnames = list(v_n, v_n, 0:(n_t - 1)))

### Fill in array
##### Parameter #############
# normal to other states
# Rates were converted to 1-year probabilities
# In the natural history module, we modeled that 8.2% of patients develop non-polypoid CRC in their lifetime by using an age-specific annual transition probability for developing non- polypoid CRC of 0.001-0.086%.
### H to other states # 29.05/100000*94097/(94097+48491)+13.68/100000*48491/(94097+48491)

age<-n_age_init+1
n_tt<-length(p_HDage)

#	annual transiction probability - 0.44/100 10-year cumulative incidence
	
	r_14<-9.35/20000


	r_14A<-3.82/20000
	r_14B<-2.18/20000
	r_14C<-1.93/20000
	r_14D<-1.42/20000

	if(Strategy=="AI1")
		HR<-HR_A1
	else if(Strategy=="AI2")
		HR<-HR_A2
	else	
		HR<-HR_A3
		
	r_14A<-1-exp(-r_14A*HR)
	r_14B<-1-exp(-r_14B*HR)
	r_14C<-1-exp(-r_14C*HR)
	r_14D<-1-exp(-r_14D*HR)
	
	a_P["H","D",1:n_tt]<-p_HDage[1:n_tt]
	a_P["H","DA",1:n_tt]<-(1-p_HDage[1:n_tt])*r_14A
	a_P["H","CL",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*r_14B
	a_P["H","CR",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*r_14C
	a_P["H","DC",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*(1-r_14C)*r_14D
	a_P["H","H",1:n_tt]<-(1-p_HDage[1:n_tt])*(1-r_14A)*(1-r_14B)*(1-r_14C)*(1-r_14D)
	
##### High risk surveillance - annual probability of CRC
	r_34<-0.0011
	r_32<-0.00
	
#### first surveillance 3 years
        
#	r_34A<-2.6/10000       # 2.6 5.87/10000 # 0.36*r_34
#	r_34B<-4.1/10000        # 4.1 9.23/10000 # 0.34*r_34
#	r_34C<-2.8/10000        # 2.8 6.29/10000 # 0.25*r_34
#	r_34D<-1.5/10000        # 1.5 3.45/10000 # 0.05*r_34


	if(Strategy=="AI1")
		HR<-1.37
	else if(Strategy=="AI2")
		HR<-0.95
	else	
		HR<-0.89 
	
	r_34A<-1-exp(-2.6/10000*3*HR)        # 2.6 5.87/10000 # 0.36*r_34
	r_34B<-1-exp(-4.1/10000*3*HR)        # 4.1 9.23/10000 # 0.34*r_34
	r_34C<-1-exp(-2.8/10000*3*HR)        # 2.8 6.29/10000 # 0.25*r_34
	r_34D<-1-exp(-1.5/10000*3*HR)        # 1.5 3.45/10000 # 0.05*r_34

	a_P["HG","D",1:2]<-p_HDage[1:2]
	a_P["HG","HG",1:2]<-(1-p_HDage[1:2])
	
	a_P["HG","D",3]<-p_HDage[3]
	a_P["HG","SympA",3]<-(1-p_HDage[3])*r_34A
	a_P["HG","SympL",3]<-(1-p_HDage[3])*(1-r_34A)*r_34B
	a_P["HG","SympR",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*r_34C
	a_P["HG","SympD",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*(1-r_34C)*r_34D
	a_P["HG","HG",3]<-(1-p_HDage[3])*(1-r_34A)*(1-r_34B)*(1-r_34C)*(1-r_34D)
	
	a_P["HG","D",4:5]<-p_HDage[4:5]
	a_P["HG","HG",4:5]<-(1-p_HDage[4:5])
	
	r_34A<-1-exp(-2.6/10000*3*HR*0.81)       # 2.6 5.87/10000 # 0.36*r_34
	r_34B<-1-exp(-4.1/10000*3*HR*0.81)        # 4.1 9.23/10000 # 0.34*r_34
	r_34C<-1-exp(-2.8/10000*3*HR*0.81)        # 2.8 6.29/10000 # 0.25*r_34
	r_34D<-1-exp(-1.5/10000*3*HR*0.81)        # 1.5 3.45/10000 # 0.05*r_34
	
	a_P["HG","D",6]<-p_HDage[6]
	a_P["HG","SympA",6]<-(1-p_HDage[6])*r_34A
	a_P["HG","SympL",6]<-(1-p_HDage[6])*(1-r_34A)*r_34B
	a_P["HG","SympR",6]<-(1-p_HDage[6])*(1-r_34A)*(1-r_34B)*r_34C
	a_P["HG","SympD",6]<-(1-p_HDage[6])*(1-r_34A)*(1-r_34B)*(1-r_34C)*r_34D
	a_P["HG","HG",6]<-(1-p_HDage[6])*(1-r_34A)*(1-r_34B)*(1-r_34C)*(1-r_34D)

	a_P["HG","D",7:n_tt]<-p_HDage[7:n_tt]
	a_P["HG","HG",7:n_tt]<-(1-p_HDage[7:n_tt])
		
# DA (4) to other states CL (5) D (11) DA (4) SympL (8)

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_45<-0.51 # 0.51 # (0.50, 0.89)  
	r_48<-0.09 # 0.09 (0.0694, 0.1006)    
	    
      	a_P["DA","D",i]<-p_HDage[i]
	a_P["DA","SympA",i]<-(1-p_HDage[i])*r_48
	a_P["DA","CL",i]<-(1-p_HDage[i])*(1-r_48)*r_45
	a_P["DA","DA",i]<-(1-r_48)*(1-p_HDage[i])*(1-r_45)      	  	
}
se_crc<-0.98

a_P["DA","SympA",1]<-se_crc
a_P["DA","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["DA","DA",1]<-(1-se_crc)*(1-p_HDage[1])

# CL (5) to other states CR (6), D (11) CL (5), SympL (8)

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_56<-0.43 # 0.50 # 0.69 (0.50, 0.70)	
	r_58<-0.17 # (0.12, 0.18)
		
      	a_P["CL","D",i]<-p_HDage[i]
	a_P["CL","SympL",i]<-(1-p_HDage[i])*r_58
	a_P["CL","CR",i]<-(1-r_58)*(1-p_HDage[i])*r_56	
	a_P["CL","CL",i]<-(1-p_HDage[i])*(1-r_56)*(1-r_58)
}

se_crc<-0.98

a_P["CL","SympL",1]<-se_crc
a_P["CL","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["CL","CL",1]<-(1-se_crc)*(1-p_HDage[1])

# CR (6) to other states DC (7) SympD (9) D (11) CR (6)

for(i in 2:length(p_HDage)){

    
	age<-n_age_init+i
	
	r_67<-0.59 # 0.59 # 0.71 (0.59, 0.73)
	r_69<-0.37 # 0.37 (0.30, 0.39)	

# probability presenting sympts with Reg. 0.49 (0.4115, 0.5269) preseting sympts with Reg
	
      	a_P["CR","D",i]<-p_HDage[i]
	a_P["CR","SympR",i]<-(1-p_HDage[i])*r_69
	a_P["CR","DC",i]<-(1-p_HDage[i])*(1-r_69)*r_67
	a_P["CR","CR",i]<-(1-p_HDage[i])*(1-r_69)*(1-r_67)	
		
}

se_crc<-0.98

a_P["CR","SympR",1]<-se_crc
a_P["CR","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["CR","CR",1]<-(1-se_crc)*(1-p_HDage[1])

# DC (7) to other states SympD (10); D (11); 

for(i in 2:length(p_HDage)){
    
	age<-n_age_init+i

	r_710<-0.65 # 0.82 (0.6109, 0.9891) 0.65 (0.65, 0.92)
		
      	a_P["DC","D",i]<-p_HDage[i]
	a_P["DC","SympD",i]<-r_710*(1-p_HDage[i])
	a_P["DC","DC",i]<-(1-r_710)*(1-p_HDage[i])
}

se_crc<-0.98

a_P["DC","SympR",1]<-se_crc
a_P["DC","D",1]<-(1-se_crc)*(p_HDage[1])
a_P["DC","DC",1]<-(1-se_crc)*(1-p_HDage[1])

# Clinical Cancer to other study - It was assumed that all those surviving for five years would no longer be at risk from CRC mortality. In the model, those diagnosed with CRC are split into fatal and non-fatal CRC health states according to the proportions given by the five year survival data.
# OS Dukes A 0.01568434/year 
# Supplement to: Overall and stage-specific survival of patients with screen-detected colorectal cancer in European countries: a population-based study in 9 countries
## 95.7 (94.3-96.8) screening arm vs. 93.1 (90.9-94.7) no-screening
## 94.6 (92.1-96.3)  screening vs. 85.1 (82.8-87.1)

# r_1<-0.028 # 0.02900678 # 91.0 (89.2-92.4) 5-year OS 86.7 (86.0-87.4) in no-screening and 92.4 (91.6-93.1) in screening 

r_1<-psa$death_S1 

hr_S1<-psa$hr_S1

if(Strategy!="NS")
   r_1<-hr_S1*r_1

# p_S1<-r_1
# r_1<-p_S1

p_S1<-RateToProb(r_1,1)

a_P["SympA","DL",]<-r_1
a_P["SympA","D",]<-(1-r_1)*p_HDage
a_P["SympA","SA",]<-(1-r_1)*(1-p_HDage)

r_1<-psa$death_S2  # 0.047 # 0.04663878 # OS 5-years 79.2 (77.6-82.5) in no-screening vs. 87.9 (86.6-89.1) in screening

hr_S2<-psa$hr_S2

if(Strategy!="NS")
r_1<-hr_S2*r_1

p_S2<-RateToProb(r_1,1)
# p_S2<-r_1
r_1<-p_S2

a_P["SympL","DL",]<-r_1
a_P["SympL","D",]<-(1-r_1)*(p_HDage)
a_P["SympL","SL",]<-(1-r_1)*(1-p_HDage)

# https://www.sciencedirect.com/science/article/pii/S1542356523001775#appsec1
# r_1<-0.08249794 # 5-year OS 66.2 (65.3-66.9) in no-screening vs, 80.7 (79.3-82.0)

r_1<-psa$death_S3

hr_S3<-psa$hr_S3

if(Strategy!="NS")
 r_1<-hr_S3*r_1

p_S3<-RateToProb(r_1,1)

p_S3<-r_1
r_1<-p_S3

a_P["SympR","DR",]<-r_1
a_P["SympR","D",]<-(1-r_1)*(p_HDage)
a_P["SympR","SR",]<-(1-r_1)*(1-p_HDage)

# r_1<-0.4080442 # 13.4 (11.2-15.8) 32.3 (29.4-35.2) in screening vs. 13.9 (13.3-14.5) in no-screening

r_1<-psa$death_S4

hr_S4<-psa$hr_S4

if(Strategy!="NS")
	r_1<-hr_S4*r_1
	
p_S4<-RateToProb(r_1,1)
# p_S4<-r_1
r_1<-p_S4

a_P["SympD","DD",]<-r_1
a_P["SympD","D",]<-(1-r_1)*(p_HDage)
a_P["SympD","SympD1",]<-(1-p_HDage)*(1-r_1)

a_P["SympD1","DD",]<-r_1
a_P["SympD1","D",]<-(1-r_1)*(p_HDage)
a_P["SympD1","SympD1",]<-(1-p_HDage)*(1-r_1)

# Treatened Clinical cancer
###########
# 5 year relative survival percent 89.8 localized

r_1<-p_S1

a_P["SA","DL",]<-r_1
a_P["SA","D",]<-(1-r_1)*p_HDage
a_P["SA","SA1",]<-(1-r_1)*(1-p_HDage)

a_P["SA1","DL",]<-r_1
a_P["SA1","D",]<-(1-r_1)*(p_HDage)
a_P["SA1","SA2",]<-(1-r_1)*(1-p_HDage)

a_P["SA2","DL",]<-r_1
a_P["SA2","D",]<-(1-r_1)*(p_HDage)
a_P["SA2","SA3",]<-(1-r_1)*(1-p_HDage)

a_P["SA3","D",]<-r_1
a_P["SA3","DL",]<-(1-r_1)*(p_HDage)
a_P["SA3","SurvivalA",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S2

a_P["SL","DL",]<-r_1
a_P["SL","D",]<-(1-r_1)*(p_HDage)
a_P["SL","SL1",]<-(1-r_1)*(1-p_HDage)

a_P["SL1","DL",]<-r_1
a_P["SL1","D",]<-(1-r_1)*(p_HDage)
a_P["SL1","SL2",]<-(1-r_1)*(1-p_HDage)

a_P["SL2","DL",]<-r_1
a_P["SL2","D",]<-(1-r_1)*(p_HDage)
a_P["SL2","SL3",]<-(1-r_1)*(1-p_HDage)

a_P["SL3","DL",]<-r_1
a_P["SL3","D",]<-(1-r_1)*(p_HDage)
a_P["SL3","SurvivalL",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S3

a_P["SR","DR",]<-r_1
a_P["SR","D",]<-(1-r_1)*(p_HDage)
a_P["SR","SR1",]<-(1-r_1)*(1-p_HDage)

a_P["SR1","DR",]<-r_1
a_P["SR1","D",]<-(1-r_1)*(p_HDage)
a_P["SR1","SR2",]<-(1-r_1)*(1-p_HDage)

a_P["SR2","DR",]<-r_1
a_P["SR2","D",]<-(1-r_1)*(p_HDage)
a_P["SR2","SR3",]<-(1-r_1)*(1-p_HDage)

a_P["SR3","DR",]<-r_1
a_P["SR3","D",]<-(1-r_1)*(p_HDage)
a_P["SR3","SurvivalR",]<-(1-r_1)*(1-p_HDage)

a_P["SurvivalL","D",]<-p_HDage
a_P["SurvivalL","SurvivalL",]<-(1-p_HDage)

a_P["SurvivalR","D",]<-p_HDage
a_P["SurvivalR","SurvivalR",]<-(1-p_HDage)

a_P["SurvivalA","D",]<-p_HDage
a_P["SurvivalA","SurvivalA",]<-(1-p_HDage)

a_P["D","D",]<-1
a_P["DD","DD",]<-1
a_P["DL","DL",]<-1
a_P["DR","DR",]<-1

a_P["PHG","D",]<-p_HDage
a_P["PHG","PHG",]<-(1-p_HDage)

a_P["PH","D",]<-p_HDage
a_P["PH","PH",]<-(1-p_HDage)

a_P["PLR","D",]<-p_HDage
a_P["PLR","PLR",]<-(1-p_HDage)

return(a_P)
}


a_P_function_CRC_Wieszczy_ns<-function(n_age_init,n_age_max,p_hdage,psa){

p_HDage<-p_hdage
Strategy<-psa$Strategy


################# patients with nonadvanced adenoma at baseline have a 10-year cumulative CRC incidence and mortality of 0.44 % (95 %CI 0.31 % – 0.62 %) and 0.03 % (95 %CI 0.01 % – 0.11 %), respectively, similarly to patients without adenoma at baseline

###### whole NS incidence rate 
IR_1<-psa$IR_1

### relative risk UC - control colonoscopy
HR_1<-psa$HR_1

HR_A1<-psa$HR_A1
HR_A2<-psa$HR_A2
HR_A3<-psa$HR_A3

# Initialize 3-D array
a_P <- array(0, dim = c(n_states, n_states, n_t),dimnames = list(v_n, v_n, 0:(n_t - 1)))

### Fill in array
##### Parameter #############
# normal to other states
# Rates were converted to 1-year probabilities
# In the natural history module, we modeled that 8.2% of patients develop non-polypoid CRC in their lifetime by using an age-specific annual transition probability for developing non- polypoid CRC of 0.001-0.086%.
### H to other states # 29.05/100000*94097/(94097+48491)+13.68/100000*48491/(94097+48491)

for(i in 1:length(p_HDage))
{
	age<-n_age_init+i
	
	if(i<2)
		r_14<-IR_1    # 0.001153323*1.25 
	else if(i<4)
		r_14<-IR_1*1.04        # 0.001199438*1.25 
	else if(i<5)
		r_14<-IR_1*1.26	       # 0.001449599*1.25
	else if(i<8)
		r_14<-IR_1*1.45        # 0.0016743*1.25 
	else
		r_14<-IR_1*1.46        # 0.001685839*1.25 
		
	r_14<-RateToProb(r_14,1)	
	p_14<-r_14
######################################################

	r_34<-p_14*3.10
	
	a_P["H","D",i]<-p_HDage[i]
	a_P["H","DA",i]<-(1-p_HDage[i])*r_14
	a_P["H","H",i]<-(1-p_HDage[i])*(1-r_14)
		
	a_P["HG","D",i]<-p_HDage[i]
	a_P["HG","DA",i]<-(1-p_HDage[i])*r_34
	a_P["HG","HG",i]<-(1-p_HDage[i])*(1-r_34)

	a_P["LR","D",i]<-p_HDage[i]
	a_P["LR","LR",i]<-(1-p_HDage[i])
	
}

# DA (4) to other states CL (5) D (11) DA (4) SympL (8)

for(i in 1:length(p_HDage)){
    
	age<-n_age_init+i

	r_45<-0.51 # 0.51 # (0.50, 0.89)  
	r_48<-0.09 # 0.09 (0.0694, 0.1006)    
	    
      	a_P["DA","D",i]<-p_HDage[i]
	a_P["DA","SympA",i]<-(1-p_HDage[i])*r_48
	a_P["DA","CL",i]<-(1-p_HDage[i])*(1-r_48)*r_45
	a_P["DA","DA",i]<-(1-r_48)*(1-p_HDage[i])*(1-r_45)      	  	
}

# CL (5) to other states CR (6), D (11) CL (5), SympL (8)

for(i in 1:length(p_HDage)){
    
	age<-n_age_init+i

	r_56<-0.43 # 0.50 # 0.69 (0.50, 0.70)	
	r_58<-0.17 # (0.12, 0.18)
		
      	a_P["CL","D",i]<-p_HDage[i]
	a_P["CL","SympL",i]<-(1-p_HDage[i])*r_58
	a_P["CL","CR",i]<-(1-r_58)*(1-p_HDage[i])*r_56	
	a_P["CL","CL",i]<-(1-p_HDage[i])*(1-r_56)*(1-r_58)
}

# CR (6) to other states DC (7) SympD (9) D (11) CR (6)

for(i in 1:length(p_HDage)){

    
	age<-n_age_init+i
	
	r_67<-0.59 # 0.59 # 0.71 (0.59, 0.73)
	r_69<-0.37 # 0.37 (0.30, 0.39)	

# probability presenting sympts with Reg. 0.49 (0.4115, 0.5269) preseting sympts with Reg
	
      	a_P["CR","D",i]<-p_HDage[i]
	a_P["CR","SympR",i]<-(1-p_HDage[i])*r_69
	a_P["CR","DC",i]<-(1-p_HDage[i])*(1-r_69)*r_67
	a_P["CR","CR",i]<-(1-p_HDage[i])*(1-r_69)*(1-r_67)	
		
}

# DC (7) to other states SympD (10); D (11); 

for(i in 1:length(p_HDage)){
    
	age<-n_age_init+i

	r_710<-0.65 # 0.82 (0.6109, 0.9891) 0.74 (0.65, 0.92)
		
      	a_P["DC","D",i]<-p_HDage[i]
	a_P["DC","SympD",i]<-r_710*(1-p_HDage[i])
	a_P["DC","DC",i]<-(1-r_710)*(1-p_HDage[i])
}

# Clinical Cancer to other study - It was assumed that all those surviving for five years would no longer be at risk from CRC mortality. In the model, those diagnosed with CRC are split into fatal and non-fatal CRC health states according to the proportions given by the five year survival data.
# OS Dukes A 0.01568434/year 
# Supplement to: Overall and stage-specific survival of patients with screen-detected colorectal cancer in European countries: a population-based study in 9 countries
## 95.7 (94.3-96.8) screening arm vs. 93.1 (90.9-94.7) no-screening
## 94.6 (92.1-96.3)  screening vs. 85.1 (82.8-87.1)

# r_1<-0.028 # 0.02900678 # 91.0 (89.2-92.4) 5-year OS 86.7 (86.0-87.4) in no-screening and 92.4 (91.6-93.1) in screening 

r_1<-psa$death_S1 

hr_S1<-psa$hr_S1

if(Strategy!="NS")
   r_1<-hr_S1*r_1

p_S1<-r_1

# p_S1<-RateToProb(r_1,1)
# r_1<-p_S1

a_P["SympA","DL",]<-r_1
a_P["SympA","D",]<-(1-r_1)*p_HDage
a_P["SympA","SA",]<-(1-r_1)*(1-p_HDage)

r_1<-psa$death_S2  # 0.047 # 0.04663878 # OS 5-years 79.2 (77.6-82.5) in no-screening vs. 87.9 (86.6-89.1) in screening

hr_S2<-psa$hr_S2

if(Strategy!="NS")
r_1<-hr_S2*r_1

# p_S2<-RateToProb(r_1,1)
p_S2<-r_1
r_1<-p_S2

a_P["SympL","DL",]<-r_1
a_P["SympL","D",]<-(1-r_1)*(p_HDage)
a_P["SympL","SL",]<-(1-r_1)*(1-p_HDage)

# https://www.sciencedirect.com/science/article/pii/S1542356523001775#appsec1
# r_1<-0.08249794 # 5-year OS 66.2 (65.3-66.9) in no-screening vs, 80.7 (79.3-82.0)

r_1<-psa$death_S3

hr_S3<-psa$hr_S3

if(Strategy!="NS")
 r_1<-hr_S3*r_1

# r_1<-RateToProb(r_1,1)

#p_S3<-RateToProb(r_1,1)

p_S3<-r_1
r_1<-p_S3

a_P["SympR","DR",]<-r_1
a_P["SympR","D",]<-(1-r_1)*(p_HDage)
a_P["SympR","SR",]<-(1-r_1)*(1-p_HDage)

# r_1<-0.4080442 # 13.4 (11.2-15.8) 32.3 (29.4-35.2) in screening vs. 13.9 (13.3-14.5) in no-screening

r_1<-psa$death_S4

hr_S4<-psa$hr_S4

if(Strategy!="NS")
r_1<-hr_S4*r_1

# p_S4<-RateToProb(r_1,1)

p_S4<-r_1
r_1<-p_S4

a_P["SympD","DD",]<-r_1
a_P["SympD","D",]<-(1-r_1)*(p_HDage)
a_P["SympD","SympD1",]<-(1-p_HDage)*(1-r_1)

a_P["SympD1","DD",]<-r_1
a_P["SympD1","D",]<-(1-r_1)*(p_HDage)
a_P["SympD1","SympD1",]<-(1-p_HDage)*(1-r_1)

# Treatened Clinical cancer
###########
# 5 year relative survival percent 89.8 localized

r_1<-p_S1

a_P["SA","DL",]<-r_1
a_P["SA","D",]<-(1-r_1)*p_HDage
a_P["SA","SA1",]<-(1-r_1)*(1-p_HDage)

a_P["SA1","DL",]<-r_1
a_P["SA1","D",]<-(1-r_1)*(p_HDage)
a_P["SA1","SA2",]<-(1-r_1)*(1-p_HDage)

a_P["SA2","DL",]<-r_1
a_P["SA2","D",]<-(1-r_1)*(p_HDage)
a_P["SA2","SA3",]<-(1-r_1)*(1-p_HDage)

a_P["SA3","D",]<-r_1
a_P["SA3","DL",]<-(1-r_1)*(p_HDage)
a_P["SA3","SurvivalA",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S2

a_P["SL","DL",]<-r_1
a_P["SL","D",]<-(1-r_1)*(p_HDage)
a_P["SL","SL1",]<-(1-r_1)*(1-p_HDage)

a_P["SL1","DL",]<-r_1
a_P["SL1","D",]<-(1-r_1)*(p_HDage)
a_P["SL1","SL2",]<-(1-r_1)*(1-p_HDage)

a_P["SL2","DL",]<-r_1
a_P["SL2","D",]<-(1-r_1)*(p_HDage)
a_P["SL2","SL3",]<-(1-r_1)*(1-p_HDage)

a_P["SL3","DL",]<-r_1
a_P["SL3","D",]<-(1-r_1)*(p_HDage)
a_P["SL3","SurvivalL",]<-(1-r_1)*(1-p_HDage)

r_1<-p_S3

a_P["SR","DR",]<-r_1
a_P["SR","D",]<-(1-r_1)*(p_HDage)
a_P["SR","SR1",]<-(1-r_1)*(1-p_HDage)

a_P["SR1","DR",]<-r_1
a_P["SR1","D",]<-(1-r_1)*(p_HDage)
a_P["SR1","SR2",]<-(1-r_1)*(1-p_HDage)

a_P["SR2","DR",]<-r_1
a_P["SR2","D",]<-(1-r_1)*(p_HDage)
a_P["SR2","SR3",]<-(1-r_1)*(1-p_HDage)

a_P["SR3","DR",]<-r_1
a_P["SR3","D",]<-(1-r_1)*(p_HDage)
a_P["SR3","SurvivalR",]<-(1-r_1)*(1-p_HDage)

a_P["SurvivalL","D",]<-p_HDage
a_P["SurvivalL","SurvivalL",]<-(1-p_HDage)

a_P["SurvivalR","D",]<-p_HDage
a_P["SurvivalR","SurvivalR",]<-(1-p_HDage)

a_P["SurvivalA","D",]<-p_HDage
a_P["SurvivalA","SurvivalA",]<-(1-p_HDage)

a_P["D","D",]<-1
a_P["DD","DD",]<-1
a_P["DL","DL",]<-1
a_P["DR","DR",]<-1

a_P["PHG","D",]<-p_HDage
a_P["PHG","PHG",]<-(1-p_HDage)

a_P["PH","D",]<-p_HDage
a_P["PH","PH",]<-(1-p_HDage)

return(a_P)
}

